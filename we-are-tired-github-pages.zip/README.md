# We Are Tired — Multi-page website

A lightweight, responsive, static website built with plain HTML, CSS, and JavaScript.

## Pages

- `index.html` — Home
- `vision.html` — Our vision
- `why.html` — Our reason and founder's motivation
- `principles.html` — The principles behind the mission
- `projects.html` — Areas we want to build in
- `contact.html` — Get involved
- `404.html` — Custom not-found page

Shared assets are in `assets/css/` and `assets/js/`.

## Run locally

No build tools, package manager, API key, or framework are required. Open `index.html` in a browser, or serve this folder with any static web server.

## Publish with GitHub Pages

1. Create a GitHub repository.
2. Extract this ZIP file.
3. Upload the **contents** of this folder to the repository's root (so `index.html` is at the top level, not buried inside another folder).
4. Commit the files to the branch you want to publish.
5. In the repository, open **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**.
7. Select your publishing branch (usually `main`) and the `/(root)` folder, then save.
8. Wait for GitHub Pages to finish deploying. Your site will be available at the URL shown in Settings → Pages.

All internal links and asset paths are relative, so the site works as a GitHub Pages project site as well as a custom domain.

## Before publishing

- `contact.html` deliberately does not invent a public email address or social account. Add the official contact details when you have them.
- The Projects page describes areas you intend to explore; it does not claim that unfinished projects are already available.
- Update the copyright year in the shared page footers when needed.
- Add your official social links and privacy policy when those are ready.

## Customize

- Colors, layout, typography, responsiveness, and animations: `assets/css/styles.css`
- Mobile navigation and scroll-reveal animation: `assets/js/main.js`
- Page content and navigation labels: the corresponding `.html` files

The site respects `prefers-reduced-motion` for visitors who have reduced motion enabled.
